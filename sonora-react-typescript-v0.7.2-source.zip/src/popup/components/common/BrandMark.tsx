export function BrandMark(): any {
  return <span className="brand-mark" aria-hidden="true"><i /><i /><i /></span>;
}
